"""
bor_logic.py — Pure BOR strategy logic (no broker dependency).

BOR = Break-of-Range
At each session open (Tokyo / London) we snapshot:
  - pre_high / pre_low  : last CLOSED 15-min candle before the session
  - open_high / open_low: first 15-min candle of the session

Sort those 4 values → s1 (highest) … s4 (lowest).

Buy  signal : close crosses ABOVE s1  → entry=s1, SL=s2, TP=entry+(entry-SL)*10
Sell signal : close crosses BELOW s4  → entry=s4, SL=s3, TP=entry-(SL-entry)*10

Session rules
  - max MAX_TRADES_PER_SESSION signals per session
  - stop all signals once a WIN is recorded in that session
  - wick-out filter: if the previous loss was a wick-out (SL wick but body
    did NOT close beyond SL), the next same-direction signal is only valid
    if the breakout candle CLOSES beyond the previous entry price
"""

from dataclasses import dataclass, field
from typing import Optional
import datetime


# ── helpers ──────────────────────────────────────────────────────────────────

def sort4(a, b, c, d):
    """Return (s1, s2, s3, s4) sorted high → low."""
    vals = sorted([a, b, c, d], reverse=True)
    return tuple(vals)


def in_session(utc_dt: datetime.datetime, start: tuple, end: tuple) -> bool:
    """True if utc_dt falls inside [start, end) (hour, minute) UTC."""
    t = utc_dt.hour * 60 + utc_dt.minute
    s = start[0] * 60 + start[1]
    e = end[0]   * 60 + end[1]
    if s < e:
        return s <= t < e
    # overnight session (e.g. 21:00 – 06:00)
    return t >= s or t < e


# ── data classes ─────────────────────────────────────────────────────────────

@dataclass
class BORLevels:
    s1: float = float("nan")
    s2: float = float("nan")
    s3: float = float("nan")
    s4: float = float("nan")

    @property
    def valid(self):
        import math
        return not any(math.isnan(v) for v in (self.s1, self.s2, self.s3, self.s4))


@dataclass
class Trade:
    symbol:    str
    session:   str          # "tokyo" | "london"
    direction: str          # "buy"   | "sell"
    entry:     float
    sl:        float
    tp:        float
    lot_size:  float
    open_time: datetime.datetime
    ticket:    int = 0      # broker order ticket (live only)

    # outcome
    closed:    bool  = False
    won:       Optional[bool] = None
    close_price: Optional[float] = None
    close_time:  Optional[datetime.datetime] = None

    # wick-out tracking
    wicked_out: bool = False


@dataclass
class SessionState:
    name:        str
    start:       tuple
    end:         tuple
    levels:      BORLevels = field(default_factory=BORLevels)
    initialized: bool  = False   # levels snapshotted this session?
    won:         bool  = False
    trade_count: int   = 0
    active_trade: Optional[Trade] = None

    # wick-out memory (persists across the session boundary for 2nd-signal filter)
    wicked_out:      bool  = False
    prev_entry:      float = float("nan")
    prev_is_buy:     bool  = False

    def reset(self):
        self.levels      = BORLevels()
        self.initialized = False
        self.won         = False
        self.trade_count = 0
        self.active_trade = None
        self.wicked_out   = False


# ── main strategy engine ──────────────────────────────────────────────────────

class BORStrategy:
    """
    Stateful BOR strategy engine.

    Call `on_candle(symbol, utc_dt, o, h, l, c, pre_h, pre_l, open_h, open_l)`
    once per closed 15-min candle.  Returns a list of signal dicts (may be empty).

    Signal dict keys:
        symbol, session, direction, entry, sl, tp, lot_size
    """

    def __init__(self, symbol: str, risk_pct: float, account_balance_fn,
                 max_trades: int = 2, tp_mult: float = 10.0,
                 tokyo_start=(0, 0), tokyo_end=(9, 0),
                 london_start=(7, 0), london_end=(16, 0)):
        self.symbol             = symbol
        self.risk_pct           = risk_pct          # e.g. 1.0 for 1 %
        self.get_balance        = account_balance_fn # callable → float
        self.max_trades         = max_trades
        self.tp_mult            = tp_mult

        self.tokyo  = SessionState("tokyo",  tokyo_start,  tokyo_end)
        self.london = SessionState("london", london_start, london_end)

        # stats
        self.wins   = 0
        self.losses = 0
        self.pnl    = 0.0

    # ── public ───────────────────────────────────────────────────────────────

    def on_candle(self, utc_dt: datetime.datetime,
                  high: float, low: float, close: float, prev_close: float,
                  pre_h: float, pre_l: float,
                  open_h: float, open_l: float) -> list:
        """
        Process one closed 15-min candle.

        pre_h / pre_l   : high/low of the candle BEFORE the session open
        open_h / open_l : high/low of the FIRST candle of the session

        Returns list of signal dicts (empty if nothing triggered).
        """
        signals = []

        for ses in (self.tokyo, self.london):
            currently_in = in_session(utc_dt, ses.start, ses.end)

            # ── session just opened → snapshot levels ─────────────────────
            if currently_in and not ses.initialized:
                ses.reset()
                s1, s2, s3, s4 = sort4(pre_h, pre_l, open_h, open_l)
                ses.levels      = BORLevels(s1, s2, s3, s4)
                ses.initialized = True

            # ── session ended → close any open trade at market ────────────
            if not currently_in and ses.active_trade and not ses.active_trade.closed:
                self._close_trade(ses, close, utc_dt, reason="session_end")

            if not currently_in:
                continue

            lvl = ses.levels
            if not lvl.valid:
                continue

            # ── check open trade outcome ──────────────────────────────────
            if ses.active_trade and not ses.active_trade.closed:
                self._check_outcome(ses, high, low, close, utc_dt)
                continue   # one trade at a time

            # ── signal conditions ─────────────────────────────────────────
            if ses.won or ses.trade_count >= self.max_trades:
                continue

            # wick-out filter
            wko_buy_ok  = (not (ses.wicked_out and ses.prev_is_buy)
                           or close > ses.prev_entry)
            wko_sell_ok = (not (ses.wicked_out and not ses.prev_is_buy)
                           or close < ses.prev_entry)

            buy_signal  = (close > lvl.s1 and prev_close <= lvl.s1 and wko_buy_ok)
            sell_signal = (close < lvl.s4 and prev_close >= lvl.s4 and wko_sell_ok)

            if buy_signal or sell_signal:
                direction = "buy" if buy_signal else "sell"
                entry = lvl.s1 if buy_signal else lvl.s4
                sl    = lvl.s2 if buy_signal else lvl.s3
                tp    = (entry + abs(entry - sl) * self.tp_mult if buy_signal
                         else entry - abs(sl - entry) * self.tp_mult)

                lot = self._calc_lot(entry, sl)
                trade = Trade(
                    symbol=self.symbol, session=ses.name,
                    direction=direction, entry=entry, sl=sl, tp=tp,
                    lot_size=lot, open_time=utc_dt
                )
                ses.active_trade = trade
                ses.trade_count += 1

                signals.append({
                    "symbol":    self.symbol,
                    "session":   ses.name,
                    "direction": direction,
                    "entry":     entry,
                    "sl":        sl,
                    "tp":        tp,
                    "lot_size":  lot,
                    "time":      utc_dt,
                })

        return signals

    # ── private ──────────────────────────────────────────────────────────────

    def _check_outcome(self, ses: SessionState,
                       high: float, low: float, close: float,
                       utc_dt: datetime.datetime):
        t = ses.active_trade
        won  = (high >= t.tp) if t.direction == "buy" else (low  <= t.tp)
        lost = (low  <= t.sl) if t.direction == "buy" else (high >= t.sl)

        if won:
            self._close_trade(ses, t.tp, utc_dt, reason="tp")
        elif lost:
            body_closed_out = (close < t.sl if t.direction == "buy"
                               else close > t.sl)
            ses.wicked_out  = not body_closed_out
            ses.prev_entry  = t.entry
            ses.prev_is_buy = (t.direction == "buy")
            self._close_trade(ses, t.sl, utc_dt, reason="sl")

    def _close_trade(self, ses: SessionState, price: float,
                     utc_dt: datetime.datetime, reason: str):
        t = ses.active_trade
        t.closed      = True
        t.close_price = price
        t.close_time  = utc_dt

        risk_dollar = self.get_balance() * self.risk_pct / 100.0

        if reason == "tp":
            t.won    = True
            ses.won  = True
            pnl      = risk_dollar * self.tp_mult
            self.wins  += 1
            self.pnl   += pnl
        elif reason == "sl":
            t.won    = False
            t.wicked_out = ses.wicked_out
            pnl      = -risk_dollar
            self.losses += 1
            self.pnl    += pnl
        else:  # session_end — flat at market
            sl_dist = abs(t.entry - t.sl)
            price_dist = (price - t.entry if t.direction == "buy"
                          else t.entry - price)
            pnl = risk_dollar * (price_dist / sl_dist) if sl_dist else 0
            if pnl >= 0:
                self.wins += 1
            else:
                self.losses += 1
            self.pnl += pnl

    def _calc_lot(self, entry: float, sl: float) -> float:
        """
        Lot size so that 1 SL distance = risk_pct % of balance.
        Returns a positive float (broker rounding done in caller).
        """
        balance   = self.get_balance()
        risk_usd  = balance * self.risk_pct / 100.0
        sl_dist   = abs(entry - sl)
        if sl_dist == 0:
            return 0.01
        # generic: lot = risk_usd / sl_dist
        # Caller should convert to broker lots using pip value
        return risk_usd / sl_dist
