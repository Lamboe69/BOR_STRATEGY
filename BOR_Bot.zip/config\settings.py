# BOR Strategy Configuration
# ─────────────────────────────────────────────────────────────────────────────
# MT5 connection
MT5_LOGIN    = 0          # your MT5 account number
MT5_PASSWORD = ""         # your MT5 password
MT5_SERVER   = ""         # your broker server name

# Symbols to trade  (MT5 symbol names — adjust to match your broker)
SYMBOLS = ["EURUSD", "XAUUSD", "US30.cash", "NAS100.cash"]

# Risk per trade as a percentage of account balance
RISK_PCT = 1.0            # 1% risk per trade

# Max trades per session (Tokyo / London each)
MAX_TRADES_PER_SESSION = 2

# Sessions in UTC  (hour, minute)
TOKYO_START  = (0,  0)
TOKYO_END    = (9,  0)
LONDON_START = (7,  0)
LONDON_END   = (16, 0)

# 15-minute timeframe used for BOR level calculation
BOR_TIMEFRAME_MINUTES = 15

# TP multiplier  (10× the SL distance)
TP_MULTIPLIER = 10

# Live bot polling interval in seconds
POLL_INTERVAL = 10
