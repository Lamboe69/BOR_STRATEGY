"""
live_bot.py — BOR Strategy live trading bot via MetaTrader 5 Python API.

Requirements:
    pip install MetaTrader5 pytz

Usage:
    1. Fill in config/settings.py with your MT5 credentials and symbol names.
    2. Run:  python python_mt5/live_bot.py
"""

import sys, time, math, logging
import datetime
import pytz
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

import MetaTrader5 as mt5
from config.settings import (
    MT5_LOGIN, MT5_PASSWORD, MT5_SERVER,
    SYMBOLS, RISK_PCT, MAX_TRADES_PER_SESSION,
    TOKYO_START, TOKYO_END, LONDON_START, LONDON_END,
    TP_MULTIPLIER, POLL_INTERVAL,
)
from bor_logic import BORStrategy, in_session

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s  %(levelname)-8s  %(message)s",
    handlers=[logging.StreamHandler(), logging.FileHandler("bor_live.log")],
)
log = logging.getLogger("BOR-Live")

UTC = pytz.utc


# ── MT5 helpers ───────────────────────────────────────────────────────────────

def connect():
    if not mt5.initialize(login=MT5_LOGIN, password=MT5_PASSWORD, server=MT5_SERVER):
        log.error("MT5 init failed: %s", mt5.last_error())
        sys.exit(1)
    info = mt5.account_info()
    log.info("Connected — account %d  balance %.2f %s",
             info.login, info.balance, info.currency)


def get_balance() -> float:
    return mt5.account_info().balance


def get_15m_candles(symbol: str, count: int = 3):
    """Return the last `count` closed 15-min OHLCV bars as list of dicts."""
    rates = mt5.copy_rates_from_pos(symbol, mt5.TIMEFRAME_M15, 1, count)
    if rates is None or len(rates) == 0:
        return []
    bars = []
    for r in rates:
        bars.append({
            "time":  datetime.datetime.fromtimestamp(r["time"], tz=UTC),
            "open":  r["open"],
            "high":  r["high"],
            "low":   r["low"],
            "close": r["close"],
        })
    return bars


def pip_value(symbol: str) -> float:
    """Return value of 1 pip in account currency per 1 standard lot."""
    info = mt5.symbol_info(symbol)
    if info is None:
        return 10.0
    # For most FX: pip = point * 10 (5-digit broker)
    # For indices / gold: point already = 1 pip
    return info.trade_tick_value / info.trade_tick_size * info.point * (
        10 if info.digits in (4, 5) else 1
    )


def calc_lot(symbol: str, entry: float, sl: float) -> float:
    """Position size so that SL distance = RISK_PCT % of balance."""
    balance  = get_balance()
    risk_usd = balance * RISK_PCT / 100.0
    sl_pips  = abs(entry - sl) / mt5.symbol_info(symbol).point
    pv       = pip_value(symbol)
    if sl_pips == 0 or pv == 0:
        return 0.01
    lot = risk_usd / (sl_pips * pv)
    info = mt5.symbol_info(symbol)
    lot  = max(info.volume_min,
               min(info.volume_max,
                   round(lot / info.volume_step) * info.volume_step))
    return lot


def place_order(symbol: str, direction: str, lot: float,
                entry: float, sl: float, tp: float) -> int:
    """Send a market order. Returns ticket number or 0 on failure."""
    order_type = mt5.ORDER_TYPE_BUY if direction == "buy" else mt5.ORDER_TYPE_SELL
    request = {
        "action":       mt5.TRADE_ACTION_DEAL,
        "symbol":       symbol,
        "volume":       lot,
        "type":         order_type,
        "price":        mt5.symbol_info_tick(symbol).ask if direction == "buy"
                        else mt5.symbol_info_tick(symbol).bid,
        "sl":           sl,
        "tp":           tp,
        "deviation":    20,
        "magic":        20240101,
        "comment":      "BOR_Bot",
        "type_time":    mt5.ORDER_TIME_GTC,
        "type_filling": mt5.ORDER_FILLING_IOC,
    }
    result = mt5.order_send(request)
    if result.retcode != mt5.TRADE_RETCODE_DONE:
        log.error("Order failed %s %s: %s", symbol, direction, result.comment)
        return 0
    log.info("Order placed  %s %s  lot=%.2f  entry=%.5f  SL=%.5f  TP=%.5f  ticket=%d",
             symbol, direction.upper(), lot, entry, sl, tp, result.order)
    return result.order


def close_position(ticket: int, symbol: str, direction: str, lot: float):
    """Close an open position by ticket."""
    close_type = mt5.ORDER_TYPE_SELL if direction == "buy" else mt5.ORDER_TYPE_BUY
    price = (mt5.symbol_info_tick(symbol).bid if direction == "buy"
             else mt5.symbol_info_tick(symbol).ask)
    request = {
        "action":       mt5.TRADE_ACTION_DEAL,
        "symbol":       symbol,
        "volume":       lot,
        "type":         close_type,
        "position":     ticket,
        "price":        price,
        "deviation":    20,
        "magic":        20240101,
        "comment":      "BOR_Bot_close",
        "type_time":    mt5.ORDER_TIME_GTC,
        "type_filling": mt5.ORDER_FILLING_IOC,
    }
    result = mt5.order_send(request)
    if result.retcode != mt5.TRADE_RETCODE_DONE:
        log.error("Close failed ticket %d: %s", ticket, result.comment)


# ── per-symbol bot ────────────────────────────────────────────────────────────

class SymbolBot:
    def __init__(self, symbol: str):
        self.symbol   = symbol
        self.strategy = BORStrategy(
            symbol=symbol,
            risk_pct=RISK_PCT,
            account_balance_fn=get_balance,
            max_trades=MAX_TRADES_PER_SESSION,
            tp_mult=TP_MULTIPLIER,
            tokyo_start=TOKYO_START,   tokyo_end=TOKYO_END,
            london_start=LONDON_START, london_end=LONDON_END,
        )
        self.last_bar_time: datetime.datetime = None
        # ticket → (direction, lot) for open positions
        self.open_positions: dict = {}

    def tick(self):
        bars = get_15m_candles(self.symbol, 3)
        if len(bars) < 2:
            return

        latest = bars[-1]   # most recently CLOSED bar
        if latest["time"] == self.last_bar_time:
            return          # already processed this bar
        self.last_bar_time = latest["time"]

        prev   = bars[-2]
        utc_dt = latest["time"]

        # Determine which session just opened to pick pre/open candles
        # pre  = bar[-2], open = bar[-1]  (standard: last closed before session,
        #                                  first closed of session)
        pre_h, pre_l   = prev["high"],   prev["low"]
        open_h, open_l = latest["high"], latest["low"]

        signals = self.strategy.on_candle(
            utc_dt=utc_dt,
            high=latest["high"], low=latest["low"],
            close=latest["close"], prev_close=prev["close"],
            pre_h=pre_h, pre_l=pre_l,
            open_h=open_h, open_l=open_l,
        )

        for sig in signals:
            lot    = calc_lot(self.symbol, sig["entry"], sig["sl"])
            ticket = place_order(self.symbol, sig["direction"],
                                 lot, sig["entry"], sig["sl"], sig["tp"])
            if ticket:
                self.open_positions[ticket] = (sig["direction"], lot)

        # Check if any open positions were closed by MT5 (SL/TP hit)
        open_tickets = {p.ticket for p in (mt5.positions_get(symbol=self.symbol) or [])}
        for ticket in list(self.open_positions):
            if ticket not in open_tickets:
                log.info("Position %d closed by broker (SL/TP)", ticket)
                del self.open_positions[ticket]

        # Session-end: close any remaining positions
        for ses in (self.strategy.tokyo, self.strategy.london):
            if not in_session(utc_dt, ses.start, ses.end):
                if ses.active_trade and not ses.active_trade.closed:
                    ticket = ses.active_trade.ticket
                    if ticket and ticket in self.open_positions:
                        direction, lot = self.open_positions[ticket]
                        close_position(ticket, self.symbol, direction, lot)
                        del self.open_positions[ticket]


# ── main loop ─────────────────────────────────────────────────────────────────

def main():
    connect()
    bots = [SymbolBot(sym) for sym in SYMBOLS]
    log.info("BOR Bot started — symbols: %s", SYMBOLS)

    try:
        while True:
            for bot in bots:
                try:
                    bot.tick()
                except Exception as exc:
                    log.exception("Error on %s: %s", bot.symbol, exc)
            time.sleep(POLL_INTERVAL)
    except KeyboardInterrupt:
        log.info("Shutting down…")
    finally:
        mt5.shutdown()


if __name__ == "__main__":
    main()
